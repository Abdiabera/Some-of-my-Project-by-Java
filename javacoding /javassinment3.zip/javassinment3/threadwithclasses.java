
package application;
class Abdi extends Thread{
	
		
		 public void run() {
				
				for (int i=0; i<5; ++i) {
					
				
				System.out.println("Hello Class");
				try { Thread.sleep(1000);} catch(InterruptedException e) {}
		 }
		 }

		};
		 class Abdisa extends Thread  {
			 
			 public void run() {
					
					for (int i=0; i<5; ++i) {
						
					
					System.out.println("Abdisa");
					
					try { Thread.sleep(1000);} catch(InterruptedException e) {}
					}
			 }
		 };

				
			 public class Main {
					
					public static void main (String[] args) {
						
				
				
					Abdi  Abdi1 = new Abdi();
					
					Abdisa Abdisa2 = new Abdisa();
					
					
					Thread t1 = new Thread(Abdi1);
					
					Thread t2= new Thread(Abdisa2);
					
					Abdi1.start();
					
					//t1.start();
					
					try { Thread.sleep(10);} 
					
					catch(InterruptedException e) {}
					
					Abdisa2.start();
					//t2.start();
					
					
					 
					}
			 }
			 
			 
			 
					 
				